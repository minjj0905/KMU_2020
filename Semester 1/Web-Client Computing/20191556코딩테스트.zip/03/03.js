
function get_wheel(e, t) {
    if(e.wheelDelta < 0) {
        t.width = width*95;
    }
}